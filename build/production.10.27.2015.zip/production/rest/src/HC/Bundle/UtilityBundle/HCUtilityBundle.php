<?php

namespace HC\Bundle\UtilityBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HCUtilityBundle extends Bundle
{
}
