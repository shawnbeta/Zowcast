<?php
namespace HC\Bundle\CoreBundle\Services;

class ConfigService
{

    const FILES = '../files/';

    const YOUTUBE_KEY = 'AIzaSyAIV2ia1Wor-vK6pLvczkTzHJmmNCpbnC8';

    const YOUTUBE_TEST_SRC = 'UC-vIANCum1yBw_4DeJImc0Q';

    //const DEMO = false;

    const PAGE_COUNT = 24;

    const TEST_ITEM_COUNT = 20;

    const EPISODE_DAY_MAX = 60;

    const DEV_SERVER_PATH = '78.74.14.2';

    const ADMIN_KEY = 'AIzaSyAIV2ia1Wor';


}