<?php

namespace HC\Bundle\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HCCoreBundle extends Bundle
{
}
