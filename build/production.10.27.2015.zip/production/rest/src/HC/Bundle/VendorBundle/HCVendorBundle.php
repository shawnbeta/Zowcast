<?php

namespace HC\Bundle\VendorBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HCVendorBundle extends Bundle
{
}
