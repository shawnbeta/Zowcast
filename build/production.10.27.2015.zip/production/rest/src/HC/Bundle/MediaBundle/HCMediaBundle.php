<?php

namespace HC\Bundle\MediaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HCMediaBundle extends Bundle
{
}
